---
name: Lapor masalah
about: Game crash, grafis masih kekunci, atau ada yang aneh
labels: bug
---

**HP kamu**
- HP:
- Chipset & GPU (misalnya Helio G99 / Mali-G57):
- Android:
- Root (Magisk / Kitsune / KernelSU / APatch):

**Game**
- Nama & package game:
- Profil yang dipakai:
- Masalahnya apa:

**Log**: buka game dulu, terus jalanin `su -c sh /data/adb/modules/ugspoof/check.sh`
```
tempel hasilnya di sini
```

**Udah dicoba**
- [ ] Force stop game terus buka lagi
- [ ] Kosongin `gl_version=`
- [ ] Set `enable_vulkan=0`
