#!/system/bin/sh
